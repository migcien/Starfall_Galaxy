import random
import json

# Read all files once and store them in variables
with open('names.txt') as f:
    names = f.read().splitlines()
with open('names.txt') as f:
    last_names = f.read().splitlines()
with open('species.txt') as f:
    species = f.read().splitlines()
with open('role.txt') as f:
    classifications = f.read().splitlines()
with open('stat_bonuses.txt') as f:
    stat_bonuses = f.read().splitlines()

def generate_metadata(number_of_sets=50):
    characters = []
    for _ in range(number_of_sets):
        character = {
            'Name': f"{random.choice(names)} {random.choice(last_names)}",
            'Age': random.randint(18, 300),
            'Species': random.choice(species),
            'Classification': random.choice(classifications),
            'Level': random.randint(1, 10),
            'Stat Bonus': random.choice(stat_bonuses),
        }
        characters.append(character)

    # Calculate rarity based on some criteria
    for character in characters:
        # Example criteria: rarity is proportional to the age of the character
        character['Rarity'] = character['Age'] / 300 * 100

    return characters

characters = generate_metadata()

with open('crew_metadata.json', 'w') as f:
    json.dump(characters, f, indent=4)
