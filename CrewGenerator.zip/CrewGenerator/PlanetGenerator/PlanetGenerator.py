import random
import json

min_mass = 1e20
max_mass = 1e25

# Read all files once and store them in variables
with open('../planet_names.txt') as f:
    planet_names = f.read().splitlines()
with open('../elements.txt') as f:
    elements = f.read().splitlines()

def generate_metadata(number_of_sets=50):
    planets = [{
        'Planet Name': "{}-{}".format(random.choice(planet_names), random.randint(0, 9999)),
        'Element': random.choice(elements),
        'Mass': random.randint(min_mass, max_mass),
        'Habitable': random.choice([True, False]),
        'Atmosphere': random.choice([True, False])
    } for _ in range(number_of_sets)]

    return planets

data = generate_metadata()

with open('planet_metadata.json', 'w') as f:
    json.dump(data, f, indent=4)

